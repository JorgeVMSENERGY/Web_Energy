# Cambios para `confiabilidad-electrica-industrial.html`

**Estado: aplicado en el parche** (sobre `docs.zip`). Este documento queda como registro para revisión: cada punto muestra el texto que estaba publicado y el texto nuevo. Los mismos cambios se replicaron en el JSON-LD de la página.

La prioridad alta corresponde a información incorrecta o desactualizada. La media corresponde a consistencia.

---

## Prioridad alta: marco regulatorio desactualizado

Desde el 18 de marzo de 2025 rige la **Ley del Sector Eléctrico (LSE)**, que sustituyó a la LIE. La **Comisión Nacional de Energía (CNE)** absorbió a la CRE. El Reglamento de la LSE se publicó en el DOF el 3 de octubre de 2025. La figura de "autoabastecimiento" ya no existe.

### 1. Metadatos (description, og, twitter)
- **Hoy:** `regulación BESS México (SENER/CRE/CFE/CENACE)`
- **Nuevo:** `regulación BESS México (SENER/CNE/CFE/CENACE)`

### 2. Sección "¿Cómo se regula el almacenamiento de energía en México?"
Sustituir la tarjeta **SENER** (cita la LTE y la LIE) y la tarjeta **CRE** completas por:

> **SENER — Secretaría de Energía · Política energética**
> Define la política y la planeación del sector eléctrico. La Ley del Sector Eléctrico (2025) y su Reglamento reconocen el almacenamiento como actividad dentro del Sistema Eléctrico Nacional.
>
> **CNE — Comisión Nacional de Energía · Permisos y regulación**
> Sustituyó a la CRE. Otorga permisos de generación a partir de 0.7 MW y permisos de almacenamiento cuando el sistema es de 0.7 MW o más y **no** está asociado a una central eléctrica o a un centro de carga. Un BESS detrás del medidor forma parte del centro de carga del usuario. Un BESS que forma parte de una central con permiso de generación no requiere permiso adicional.

Etiquetas nuevas: `LSE 2025` · `BTM: parte del centro de carga` · `Permiso CNE ≥ 0.7 MW`

### 3. Tarjeta CFE Distribución
Se conserva. Solo agregar al final: *"Generación menor a 0.7 MW: generación distribuida con contrato de interconexión, sin permiso de la CNE."*

### 4. FAQ "¿Qué permisos o regulaciones aplican para instalar un BESS en México?"
- **Hoy (último párrafo):** `…el proceso regulatorio más relevante es la notificación de autoabastecimiento a CFE…`
- **Nuevo:** *"Para un BESS industrial detrás del medidor, el sistema forma parte de su centro de carga: no requiere permiso de almacenamiento de la CNE. Sí aplican las normas técnicas de instalación (NOM-001-SEDE, NOM-029-STPS, NOM-002-STPS) y, si el BESS se integra con generación propia, el contrato de interconexión o el permiso que corresponda según la capacidad. VMS Energy identifica y gestiona la documentación como parte del alcance EPC."*

En la primera viñeta de la misma FAQ, cambiar `(CRE + CFE)` por `(CNE + CFE)`.

### 5. Botón "Consultar marco regulatorio"
El texto de apoyo dice *"en la mayoría de los casos industriales BTM, ninguno ante CRE o CENACE"*. Cambiar `CRE` por `CNE`.

---

## Prioridad alta: tarifas y cifras de peak shaving

### 6. FAQ "¿Qué es el peak shaving y cuánto puede ahorrar…?"
- **Hoy:** `Las tarifas industriales HM/HSL/HS incluyen cargos por demanda de $300–500/kW/mes…` (HM/HSL/HS son tarifas anteriores a 2018)
- **Nuevo:**
  > El peak shaving descarga el BESS durante los picos para reducir la demanda que CFE factura. En la tarifa GDMTH los cargos por demanda (capacidad y distribución) representan una parte importante del recibo, y el cargo de distribución varía mucho entre divisiones: en septiembre de 2026 iba de alrededor de 58 a 221 MXN/kW. Un BESS bien dimensionado puede reducir la demanda facturada entre 20 % y 40 %. Con perfiles favorables, el retorno se ubica típicamente por debajo de 4 años. Lo calculamos con su recibo y su curva de carga medida.

### 7. FAQ "¿Cuánto puede ahorrar una planta con tarifa GDMTH…?"
El ejemplo usa `$350–$500/kW/mes` y un retorno de `18 a 30 meses`. Otra parte de la misma página dice `18 a 36 meses`. Recomiendo quitar la cifra de $/kW, porque el cargo de capacidad no es lineal: depende de la demanda en punta y de la fórmula con factor de carga 0.57. Texto sugerido:
> **Ejemplo ilustrativo:** una planta con demanda máxima de 500 kW y base de 320 kW puede recortar su pico con un BESS de 180 kW. El ahorro depende de su división tarifaria, de cuántas horas dura el pico y de si ocurre en horario punta. Por eso lo calculamos con su recibo y no con un promedio. El retorno típico para perfiles de este tipo se ubica por debajo de 4 años.

### 8. Pregunta 2 del bloque "Antes de hablar de tecnología…"
- **Hoy:** `…le genera retorno de inversión comprobable en 18 a 36 meses.`
- **Nuevo:** `…suele generar retorno en menos de 4 años, calculado con su propio recibo.`

### 9. Tarjeta GDMTH de la sección de tarifas
- **Hoy:** `ROI típico: 18–36 meses`
- **Nuevo:** `Retorno típico: menor a 4 años`

### 10. Nota fiscal (agregar debajo de la tarjeta GDMTH)
> La deducción inmediata del 100 % (LISR art. 34, fr. XIII) aplica a maquinaria para generación renovable o cogeneración eficiente. Un BESS puede incluirse cuando forma parte de un sistema fotovoltaico; valídelo con su asesor fiscal.

---

## Prioridad alta: marca BESS (Sigenergy)

### 11. Metadatos
- **Hoy:** `BESS Livoltek/Geolis` (description) y `BESS Geolis` (og y twitter)
- **Nuevo, en los tres:** `BESS Sigenergy`

### 12. FAQ "¿Cuál es la diferencia entre baterías LFP y VRLA/AGM…?"
- **Hoy:** `Los sistemas Geolis de VMS Energy utilizan celdas LFP, certificadas bajo UL9540 / UL9540A y NFPA 855…`
- Hay dos problemas:
  - La marca cambió.
  - La misma página explica que NFPA 855 es una norma de *instalación* y que UL 9540A es un *método de ensayo*, no un certificado. La frase se contradice con la propia página.
- **Nuevo:** *"Nuestra plataforma de referencia, Sigenergy SigenStack, usa módulos LFP de 12 kWh con gestión de seguridad a nivel de pack; sus ensayos UL 9540A e IEC 62619 están documentados con Intertek. NFPA 855 la cumplimos en el diseño de la instalación."*

### 13. FAQ "¿Cuándo conviene combinar BESS con generación solar…?"
- **Hoy:** `Con inversores Livoltek + Geolis, VMS Energy logra tasas de autoconsumo solar superiores al 85%.`
- **Nuevo:** `Con almacenamiento bien dimensionado, el autoconsumo de la energía solar aumenta de forma significativa; lo modelamos con su curva de carga antes de proponer capacidad.` Si Comercial tiene un proyecto propio con la cifra medida, se puede publicar ese dato.

### 14. Resto de menciones de marca
- Paso 3 del proceso: `Para Borri y Geolis` → `Para Borri y Sigenergy`
- Bloque de partners: `Borri (90+ años, Grupo Legrand), Geolis (tropicalizado para México), Livoltek, WEG` → `Borri (UPS), Sigenergy (BESS), WEG`. Hay que confirmar si Borri sigue siendo la marca de UPS.
- "Servicios complementarios → Procura especializada": `Borri, Geolis, Livoltek y WEG` → `Borri, Sigenergy y WEG`
- "Servicios complementarios → Energía Solar Industrial": `Autoconsumo >85% con inversor Livoltek integrado` → `Solar + BESS: energía solar gestionable, no intermitente.`

---

## Prioridad media: enlaces a las páginas nuevas

### 15. "Servicios complementarios"
- **Monitoreo y SCADA Industrial**: cambiar el texto a `EMS/PMS que coordina UPS, BESS, generación y solar, integrado al SCADA de su planta.` y el enlace a `arquitectura-disponibilidad-electrica.html#ems`.
- **Generación de Respaldo**: cambiar el enlace de `soluciones_verde_no_solar.html` a `generacion-en-sitio-cogeneracion.html`.
- **Agregar** una tarjeta: `Plantas de Emergencia` → `lp-plantas-de-emergencia-industriales.html`, con el texto `Dimensionamiento, transferencia automática, paralelismo y mantenimiento multimarca.`

### 16. Tabla "¿BESS, UPS o generador?"
- En la fila "Se pueden combinar", enlazar "arquitecturas híbridas" a `arquitectura-disponibilidad-electrica.html`.
- En la fila "Integración solar / FV", columna Generador: `No compatible directamente` → `Requiere un controlador que coordine generador e inversores`. Hoy es técnicamente discutible.
- En el párrafo que sigue a la tabla, cambiar el enlace "Solicite una evaluación de arquitectura de confiabilidad" a `arquitectura-disponibilidad-electrica.html`.

### 17. Menú y pie
Esta página también necesita las tres entradas nuevas del menú (Soluciones → Energía) y del pie, y el cambio de etiqueta "Turbogeneradores Woodward" → "Control de Turbogeneradores". Es el mismo cambio que el parche aplica a las 47 páginas del ZIP. Aplicado.
