# PR: Generación en sitio, plantas de emergencia y arquitectura de disponibilidad

**Solicitante:** Mercadotecnia (Hugo Díaz)
**Fecha:** 27 de septiembre de 2026
**Rama sugerida:** `feature/generacion-disponibilidad`
**Alcance:** 3 páginas nuevas y 91 archivos modificados sobre el repositorio completo (`docs.zip`): menú y pie en 85 páginas, 2 fragmentos y 3 páginas en inglés; contenido en 7 páginas; sitemap.

> **Importante:** `.github/workflows/deploy-production.yml` publica en producción con cada push a `main`. Este cambio debe entrar por rama y PR; **el merge a `main` equivale a publicar**.

## Objetivo

La web no tenía información suficiente sobre cogeneración, generación diésel y la arquitectura completa de disponibilidad (red + generador + UPS + BESS + solar + control/EMS). Este PR agrega tres landing pages, las enlaza desde el menú de todo el sitio y corrige errores de contenido encontrados en la auditoría.

## Contenido del paquete

| Archivo | Para qué |
|---|---|
| `cambios-generacion-disponibilidad.patch` | Parche git contra el repositorio completo (`docs.zip`). Se probó que aplica limpio (`git apply --check`). |
| `archivos/` | Los 94 archivos finales (3 nuevos + 91 modificados) con su ruta relativa, por si prefieren copiarlos en lugar de aplicar el parche. |
| `menu_update.py` | Script idempotente que agrega las entradas de menú. Ya se corrió; queda para futuras páginas nuevas. |
| `CAMBIOS-confiabilidad-electrica-industrial.md` | Registro de los cambios aplicados a Confiabilidad (texto anterior contra texto nuevo), para revisión. |

## Páginas nuevas

| URL | Contenido |
|---|---|
| `/arquitectura-disponibilidad-electrica.html` | Hub: diagrama unifilar de 6 capas, tabla por capa, secuencia ante falla de red, clasificación de cargas, EMS/PMS, BESS Sigenergy, economía GDMTH y marco LSE/CNE, FAQ. |
| `/generacion-en-sitio-cogeneracion.html` | Cogeneración de vapor (ingenios, papel, geotérmica), motores y turbinas, generación en paralelo con red, permisos y deducción fiscal, 9 proyectos del CV 2026, FAQ. |
| `/lp-plantas-de-emergencia-industriales.html` | Dimensionamiento, tipos de transferencia (ATS), paralelismo y deslastre, programa de mantenimiento y pruebas, normas, 6 proyectos del CV 2026, FAQ. |

Las tres usan la plantilla existente: `data-concept="servicios-especializados"`, núcleo (`tokens.css`, `vms-core.css`, `vms-header.css`, `vms-header.js`) y `servicios-base.css`. El encabezado y el pie se copiaron de `lp-turbogeneradores-woodward.html`. **No se agregaron hojas de estilo ni scripts nuevos.** El CSS propio de cada página va en su `<style>`. Incluyen JSON-LD Service, FAQPage y BreadcrumbList, canonical, Open Graph y hreflang.

## Archivos modificados

- **Menú y pie (47 páginas).** En *Soluciones → Energía* y en el pie se agregan:
  - "Cogeneración y Generación en Sitio"
  - "Plantas de Emergencia"
  - "Arquitectura de Disponibilidad"

  Además, "Turbogeneradores Woodward" se renombra a "Control de Turbogeneradores". La URL no cambia.
- **`lp-turbogeneradores-woodward.html`.** Enfoque multimarca y correcciones de contenido:
  - Título, meta, H1 y JSON-LD. Se quitó la mención a easYgen del meta, porque la página no la desarrolla.
  - Ubicación de Ingenio Santa Ana corregida: era "México", es Escuintla, Guatemala.
  - Se eliminó la fila vacía TG-17.
  - Se quitaron de la tabla las columnas de potencia y protocolos sin respaldo, y se corrigió la descripción del 505E.
  - Los KPI "SIL-2" y "±0.1 %" (especificaciones de producto) se sustituyeron por "4 países atendidos".
  - La FAQ offshore llamaba "plataformas" a embarcaciones de Cotemar; se corrigió.
  - 4 proyectos nuevos del CV.
  - El texto de WhatsApp decía "estudios eléctricos"; se corrigió.
- **`soluciones_verde_no_solar.html`.** El H1 y los metadatos ya no ofrecen "cogeneración": la página trata biogás, biomasa, eólica e hidro. Se agregó un enlace a la página de cogeneración.
- **`soluciones_automatizacion_control.html`.** Nueva sección `#ems-pms` (EMS/PMS con DEIF, Woodward y Schneider). La página de Confiabilidad ya remitía aquí para el EMS y la sección no existía.
- **`sitemap.xml`.** 3 URLs nuevas y `lastmod` actualizado en las 3 páginas con cambios de contenido.

## Cambios adicionales sobre el repositorio completo

- **Menú y pie** también en blog, contacto, especialidades, certificaciones, carreras, calculadora BESS, checklist, avisos legales y demás páginas con el menú del sitio. También en `partials/header.html` y `partials/footer.html`.
- **Páginas en inglés** (`en/`): tres entradas nuevas con etiqueta en inglés que enlazan a las páginas en español (`hreflang="es"`), igual que el resto de ese menú.
- **`confiabilidad-electrica-industrial.html`** con todos los cambios del documento de registro:
  - Marco LSE/CNE en lugar de LIE/CRE, y se eliminó "autoabastecimiento".
  - Tarifas GDMTH en lugar de HM/HSL/HS, y retorno unificado en "menor a 4 años".
  - Sigenergy en lugar de Geolis/Livoltek, sin afirmar certificaciones de producto no verificadas.
  - Enlaces a las tres páginas nuevas.
  - El JSON-LD se actualizó en paralelo con el texto visible.
- **`soluciones_verde_no_solar.html`**: la FAQ de datos estructurados citaba la Ley de Transición Energética y el "autoabastecimiento"; ahora cita la LSE y los umbrales de 0.7 MW.
- **`soluciones_oil_gas.html`**: "CRE / NOM-ASEA" pasa a "CNE / NOM-ASEA".
- **`soluciones.html`**: la tarjeta del catálogo de UPS/BESS dice Sigenergy en lugar de Geolis.

## Verificación que ya se hizo

- [x] Parche aplicado con `git apply --check` sobre `docs.zip`, sin conflictos.
- [x] `scripts/audit_links.py` antes y después: ningún enlace roto nuevo. Los únicos faltantes son `assets/`, que no venían en el paquete.
- [x] Etiquetas bien cerradas en las 6 páginas con contenido nuevo o editado; sin `id` duplicados introducidos.
- [x] JSON-LD válido en las 3 páginas nuevas y en la LP de turbogeneradores.
- [x] Menú: ninguna página con entradas duplicadas; revisado el desplegable en navegador.
- [x] `sitemap.xml` es XML válido (76 URLs).
- [x] Revisión visual en Chromium a 1280 px y 390 px. Las tablas y el diagrama se desplazan en horizontal dentro de su contenedor en móvil; el cuerpo no se desborda.
- [x] Todos los enlaces internos apuntan a páginas existentes en el repositorio.

## Checklist para Sistemas antes de publicar

- [ ] Aplicar el parche (o copiar `archivos/`) en una rama y revisar el diff.
- [ ] Confirmar que `contacto_cta.html` acepta estos tres valores nuevos de `?producto=` y los enruta al CRM: `arquitectura-disponibilidad`, `generacion-cogeneracion`, `plantas-emergencia`.
- [ ] Confirmar que existen en el servidor `assets/img/hero_turbogeneradores.webp` y `assets/img/services/infraestructura_electrica.webp`. Se usan como hero y og:image; la carpeta `assets/` no venía en el paquete.
- [ ] Regenerar PUBLICAR con `_f3/publicar_github.py` y confirmar que incluye las 3 páginas nuevas.
- [ ] Probar en staging: menú desplegable y móvil, CTA fijo y WhatsApp, acordeones de FAQ.
- [ ] Después de publicar: enviar el sitemap en Search Console y validar las 3 URLs con la prueba de resultados enriquecidos (FAQ).

## Fuera de alcance, para un siguiente PR

Todavía mencionan Geolis o Livoltek como marca de BESS:
- `blog-dimensionamiento-ups-industrial.html` (16 menciones de Geolis, 3 de Livoltek y tarifa HM/HSL).
- `procura.html` (bloque de representaciones y JSON-LD).
- `especialidades.html`.

No los cambié en automático por dos razones:
- Geolis también aparece como **cliente** de Oil & Gas.
- La sección de representaciones depende de logos y acuerdos comerciales.

Requieren decisión de Mercadotecnia y Comercial.

## Pendientes de Mercadotecnia (no bloquean)

- Hero de plantas de emergencia: hoy usa degradado sin foto. Idealmente, una foto propia (por ejemplo, del mantenimiento a generadores en embarcaciones de Cotemar).
- Validar con Dirección Comercial los KPI que se conservaron en la LP de turbogeneradores ("25+ turbinas", "12 ingenios", "4 plataformas", "24 h").
- Corregir en el CV 2026: Lufussa–Pavana está en **Honduras**, no en Guatemala. El CV también escribe "DSCL/MSCL"; el nombre del producto Woodward es **DSLC/MSLC**.
