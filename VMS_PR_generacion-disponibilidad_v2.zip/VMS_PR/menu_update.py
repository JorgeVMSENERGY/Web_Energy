"""Agrega las entradas de menú y pie de las páginas nuevas (sep 2026).
Uso:  python3 menu_update.py <carpeta_del_sitio>
Es idempotente: si una página ya tiene las entradas, no la toca."""
import re, pathlib, sys
R = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
SKIP = {'stand-rim-2026.html','stand-rim-2026 3.html','tabla-decision-conceptos.html'}
verde = re.compile(r'^([ \t]*)<li><a href="soluciones_verde_no_solar\.html(#inicio)?"( style="[^"]*")?>Generaci&oacute;n Verde No Solar</a></li>(\r?\n)', re.M)
conf  = re.compile(r'^([ \t]*)<li><a href="confiabilidad-electrica-industrial\.html(#inicio)?"( style="[^"]*")?>Confiabilidad El&eacute;ctrica \(UPS/BESS\)</a></li>(\r?\n)', re.M)
def add_after_verde(m):
    ind, suf, sty, nl = m.group(1), m.group(2) or '', m.group(3) or '', m.group(4)
    return (m.group(0)
      + f'{ind}<li><a href="generacion-en-sitio-cogeneracion.html{suf}"{sty}>Cogeneraci&oacute;n y Generaci&oacute;n en Sitio</a></li>{nl}'
      + f'{ind}<li><a href="lp-plantas-de-emergencia-industriales.html{suf}"{sty}>Plantas de Emergencia</a></li>{nl}')
def add_after_conf(m):
    ind, suf, sty, nl = m.group(1), m.group(2) or '', m.group(3) or '', m.group(4)
    if 'background:#0f4c81' in sty: sty = ''   # no copiar el resaltado de "pagina activa"
    return m.group(0) + f'{ind}<li><a href="arquitectura-disponibilidad-electrica.html{suf}"{sty}>Arquitectura de Disponibilidad</a></li>{nl}'
report = {}
for f in sorted(R.glob('*.html')):
    if f.name in SKIP: continue
    s = f.read_bytes().decode('utf-8')
    if '>Cogeneraci&oacute;n y Generaci&oacute;n en Sitio<' in s:
        continue
    s2, n1 = verde.subn(add_after_verde, s)
    s2, n2 = conf.subn(add_after_conf, s2)
    s2, n3 = re.subn(r'>Turbogeneradores Woodward</a>', '>Control de Turbogeneradores</a>', s2)
    if s2 != s:
        f.write_bytes(s2.encode('utf-8'))
    report[f.name] = (n1, n2, n3)
from collections import Counter
print(Counter(report.values()))
for k,v in report.items():
    if v not in [(2,2,1)]: print(k, v)
